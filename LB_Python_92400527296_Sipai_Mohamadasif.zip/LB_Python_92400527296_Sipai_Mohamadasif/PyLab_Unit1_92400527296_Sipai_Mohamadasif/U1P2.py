#Write a program to input 2 numbers and an arithmetic operator. display the result acordingly.

# Input two numbers
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

# Input operator
op = input("Enter operator (+, -, *, /): ")

# Perform operation
if op == "+":
    print("Result:", a + b)
elif op == "-":
    print("Result:", a - b)
elif op == "*":
    print("Result:", a * b)
elif op == "/":
    if b != 0:
        print("Result:", a / b)
    else:
        print("Cannot divide by zero")
else:
    print("Invalid operator")